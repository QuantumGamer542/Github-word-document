<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Grades</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-10">
<div class="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 1: Drop existing database if exists
$sql = "DROP DATABASE IF EXISTS itgrades;";
if ($conn->query($sql) === TRUE) {
    echo "Step 1: Database Deleted successfully <br/>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Step 2: Create the database
$sql = "CREATE DATABASE itgrades;";
if ($conn->query($sql) === TRUE) {
    echo "Step 2: itgrades created successfully <br/>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Reconnect using the new database
$conn = new mysqli($servername, $username, $password, "itgrades");

// Step 3: Create the table inside the new database
$sql = "CREATE TABLE inte (
    id INT NOT NULL AUTO_INCREMENT,
    course VARCHAR(25) NOT NULL,
    grade VARCHAR(3) NOT NULL,
    PRIMARY KEY (id)
) ENGINE = InnoDB;";
if ($conn->query($sql) === TRUE) {
    echo "Step 3: inte Table created successfully <br/>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
</div>
</body>
</html>
