const lyrics = [
    { time: 0, text: "Introduction - David Byrne" },
    { time: 33.5, text: "I can't seem to face up to the facts" },
    { time: 37.8, text: "I'm tense and nervous and I can't relax" },
    { time: 42.3, text: "I can't sleep 'cause my bed's on fire" },
    { time: 46.1, text: "Don't touch me, I'm a real live wire" },
    { time: 50.5, text: "Psycho Killer, qu'est-ce que c'est?" },
    { time: 55.0, text: "Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better" },
    { time: 59.8, text: "Run, run, run, run, run, run, run away, oh-oh-oh" },
    { time: 67.5, text: "Ay-ya-ya-ya-ya-ya, ooh" },
    { time: 79.7, text: "You start a conversation, you can't even finish it" },
    { time: 84.3, text: "You're talking a lot, but you're not saying anything" },
    { time: 88.0, text: "When I have nothing to say, my lips are sealed" },
    { time: 92, text: "Say something once, why say it again?" },
    { time: 97.3, text: "Psycho Killer, qu'est-ce que c'est?" },
    { time: 100.7, text: "Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better" },
    { time: 106.0, text: "Run, run, run, run, run, run, run away, oh-oh-oh" },
    { time: 114.1, text: "Psycho Killer, qu'est-ce que c'est?" },
    { time: 117.4, text: "Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better" },
    { time: 122.6, text: "Run, run, run, run, run, run, run away, oh, oh, oh, oh" },
    { time: 129.9, text: "Ay-ya-ya-ya-ya-ya" },
    { time: 134.4, text: "Ce que j'ai fait, ce soir-là" },
    { time: 142.9, text: "Ce qu'elle a dit, ce soir-là" },
    { time: 151.8, text: "Réalisant mon espoir" },
    { time: 155.8, text: "Je me lance vers la gloire, okay" },
    { time: 163.7, text: "Yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah" },
    { time: 168.3, text: "We are vain and we are blind" },
    { time: 172.3, text: "I hate people when they're not polite" },
    { time: 177.3, text: "Psycho Killer, qu'est-ce que c'est?" },
    { time: 180.7, text: "Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better" },
    { time: 185.0, text: "Run, run, run, run, run, run, run away, oh-oh-oh" },
    { time: 193.2, text: "Ai-ya-ya-ya-ya-ya, ooh" }
];
    /*
    I can't seem to face up to the facts
    I'm tense and nervous and I can't relax
    I can't sleep 'cause my bed's on fire
    Don't touch me, I'm a real live wire
    Psycho Killer
    Qu'est-ce que c'est?
    Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better
    Run, run, run, run, run, run, run away, oh-oh-oh
    Psycho Killer
    Qu'est-ce que c'est?
    Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better
    Run, run, run, run, run, run, run away, oh, oh, oh, oh
    Ay-ya-ya-ya-ya-ya, ooh
    You start a conversation, you can't even finish it
    You're talking a lot, but you're not saying anything
    When I have nothing to say, my lips are sealed
    Say something once, why say it again?
    Psycho Killer
    Qu'est-ce que c'est?
    Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better
    Run, run, run, run, run, run, run away, oh-oh-oh
    Psycho Killer
    Qu'est-ce que c'est?
    Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better
    Run, run, run, run, run, run, run away, oh, oh, oh, oh
    Ay-ya-ya-ya-ya-ya
Ce que j'ai fait, ce soir-là
Ce qu'elle a dit, ce soir-là
Réalisant mon espoir
Je me lance vers la gloire, okay
Yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah
We are vain and we are blind
I hate people when they're not polite
Psycho Killer
Qu'est-ce que c'est?
Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better
Run, run, run, run, run, run, run away, oh-oh-oh
Psycho Killer
Qu'est-ce que c'est?
Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better
Run, run, run, run, run, run, run away, oh, oh, oh, oh
Ai-ya-ya-ya-ya-ya, ooh
*/
let currentLyricIndex = 0;
const audio = document.getElementById("audio");
const lyricElement = document.getElementById("lyric");
audio.addEventListener("play", () => {
    currentLyricIndex = 0; // Reset lyrics when song starts over
    setInterval(displayLyrics, 100);
});

function displayLyrics() {
const currentTime = audio.currentTime;
// Find the current lyric based on time
if (
currentLyricIndex < lyrics.length &&
currentTime >= lyrics[currentLyricIndex].time
) {
lyricElement.textContent = lyrics[currentLyricIndex].text;
currentLyricIndex++;
}
}

