const lyrics = [
    
        { time: 0.0, text: "(Are you ready, hey, are you ready for this?)", singer: "freddie" },
        { time: 2.5, text: "(Are you hanging on the edge of your seat?)", singer: "freddie" },
        { time: 3.5, text: "I need a break beat, uh", singer: "others" },
        { time: 7.5, text: "(Are you ready, hey, are you ready for this?)", singer: "freddie" },
        { time: 10.0, text: "(Are you hanging on the edge of your seat?)", singer: "freddie" },
        { time: 12.5, text: "I need a break beat, uh", singer: "others" },
        { time: 15.0, text: "(Outta the doorway the bullets rip)", singer: "freddie" },
        { time: 17.5, text: "(Repeating to the sound of the beat, hey)", singer: "freddie" },
        
        { time: 20.0, text: "Yo, a for the kids in the club that's ready to get bugged", singer: "others" },
        { time: 22.5, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 25.0, text: "And for the thugs with the burners that wanna blast off", singer: "others" },
        { time: 27.5, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 30.0, text: "And for the kids on the blocks, shootin' at the crooked cops—blaow!", singer: "others" },
        { time: 32.5, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 35.0, text: "(And another one gone)", singer: "freddie" },
        { time: 37.5, text: "(And another one gone)", singer: "freddie" },
        { time: 40.0, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 42.5, text: "Young Free, Freddie where you at?", singer: "others" },
        
        { time: 45.0, text: "(Steve walks wearily down the street)", singer: "freddie" },
        { time: 47.5, text: "(With the brim pulled way down low)", singer: "freddie" },
        { time: 50.0, text: "Some cat up in Brooklyn just got robbed with a Kangol", singer: "others" },
        { time: 52.5, text: "(Are you ready, hey, are you ready for this?)", singer: "freddie" },
        { time: 55.0, text: "(Are you hanging on the edge of your seat?)", singer: "freddie" },
        { time: 57.5, text: "(Outta the doorway, the bullets rip)", singer: "freddie" },
        { time: 60.0, text: "(Repeating to the sound of the beat, hey)", singer: "freddie" },
        { time: 62.5, text: "My man got shot, and the block got hot", singer: "others" },
        { time: 65.0, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 67.5, text: "Yo, hey I hear more shots, this is like Fort Knox, kid", singer: "others" },
        { time: 70.0, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 72.5, text: "Yo, hold your breath", singer: "others" },
        { time: 75.0, text: "(And another one gone)", singer: "freddie" },
        { time: 77.5, text: "(And another one gone)", singer: "freddie" },
        { time: 80.0, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 82.5, text: "Yo, check it", singer: "others" },
        
        
        { time: 85.0, text: "If you're a soldier at ease", singer: "others" },
        { time: 87.5, text: "My military style is known to murder Nazis", singer: "others" },
        { time: 90.0, text: "Brooklyn to Germany (Oh yeah) come on", singer: "others" },
        { time: 92.5, text: "My kamikaze will blow the U2", singer: "others" },
        { time: 95.0, text: "They hire Idi Amin in Timbuktu", singer: "others" },
        { time: 97.5, text: "Whether you Hindu, or do the Voodoo", singer: "others" },
        { time: 100.0, text: "You can't foresee this unless I bring the previews, yeah, yeah", singer: "others" },
        { time: 102.5, text: "Yo, it's the number one rappin' band (Come on)", singer: "others" },
        { time: 105.0, text: "Yo, this review will be critically acclaimed", singer: "others" },
        { time: 107.5, text: "Leave you in critical pain, clinically insane", singer: "others" },
        { time: 110.0, text: "The name Wyclef Jean, with a yes, yes y'all", singer: "others" },
        { time: 112.5, text: "Better have a vest y'all, I'll blast, and bless y'all (Oh yeah)", singer: "others" },
        { time: 115.0, text: "F-y'all, the mark of the beast, the triple six", singer: "others" },
        { time: 117.5, text: "Time running out, listen to the tick (Oh yeah)", singer: "others" },
        { time: 120.0, text: "If you see what I saw, then you seen what I seen", singer: "others" },
        { time: 122.5, text: "If you know what I know, you know what I mean (Oh yeah)", singer: "others" },
        { time: 125.0, text: "Commanding officer of the Navy SEAL team", singer: "others" },
        { time: 127.5, text: "Once I give the orders, you feel the infrared beam (Oh yeah) Blaow!", singer: "others" },
        { time: 130.0, text: "For all you critics, sayin' 'another remake'", singer: "others" },
        { time: 132.5, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 135.0, text: "Yo, if you know the deal, this is the master reel, kid", singer: "others" },
        { time: 137.5, text: "(Another one bites the dust) (Oh yeah)", singer: "freddie" },
        { time: 140.0, text: "(And another one gone) Right", singer: "freddie" },
        { time: 142.5, text: "(And another one gone) Right", singer: "freddie" },
        { time: 145.0, text: "(Another one bites the dust, hey) Freddie Mercury, where you at yo?", singer: "others" },

        { time: 147.5, text: "(How do you think I'm gonna get along)", singer: "freddie" },
        { time: 150.0, text: "(Without you when you're gone) (Oh yeah)", singer: "freddie" },
        { time: 152.5, text: "I need a break yo", singer: "others" },
        { time: 155.0, text: "If you're ready for the first of the month", singer: "others" },
        { time: 157.5, text: "For that welfare check, come on (Kicked me out on my own)", singer: "others" },
        { time: 160.0, text: "I need a break beat", singer: "others" },
        { time: 162.5, text: "(Are you happy, are you satisfied?)", singer: "freddie" },
        { time: 165.0, text: "(How long can you stand the heat?)", singer: "freddie" },
        { time: 167.5, text: "I need a break beat", singer: "others" },
        { time: 170.0, text: "(Outta the doorway, the bullets rip)", singer: "freddie" },
        { time: 172.5, text: "(To the sound of the beat, look out)", singer: "freddie" },
        { time: 175.0, text: "Yo, bulletproof vests, like the wild, wild west", singer: "others" },
        { time: 177.5, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 180.0, text: "Yo, this is a stickup, now take off your Rolex", singer: "others" },
        { time: 182.5, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 185.0, text: "Yo, dirty money, good money, yo it's all money-money", singer: "others" },
        { time: 187.5, text: "(Another one bites the dust)", singer: "freddie" },
        { time: 190.0, text: "Yo, Dirty Cash (And another one gone)", singer: "others" },
        { time: 192.5, text: "Dirty Cash (And another one gone)", singer: "others" },
        { time: 195.0, text: "The adventures of Dirty Cash (Another one bites the dust)", singer: "others" },

        { time: 197.5, text: "Yo, for the love for the cash, I'll blast you in my path", singer: "others" },
        { time: 200.0, text: "Keep my eyes on the math, you cats don't know the half (Oh yeah)", singer: "others" },
        { time: 202.5, text: "As far as I'm concerned, you cats can burn in flames", singer: "others" },
        { time: 205.0, text: "This ain't no game, I'mma start callin' names (Oh yeah)", singer: "others" },
        { time: 207.5, text: "So come get me, if you know the one-fifty", singer: "others" },
        { time: 210.0, text: "A million refugees ready to bust with me (Oh yeah)", singer: "others" },
        { time: 212.5, text: "Bloody, filthy, in this rap shhh—", singer: "others" },
        { time: 215.0, text: "You gonna have to kill me, since you can't beat me (Oh yeah)", singer: "others" },
        { time: 217.5, text: "Pras, Dirty, Cash, you're the greedy", singer: "others" },
        { time: 220.0, text: "Believe me, you gotta let me fly like R. Kelly (Oh yeah)", singer: "others" },
        { time: 222.5, text: "Bite another dust with my man Freddie Mercury", singer: "others" },
        { time: 225.0, text: "What height nineties got ya cash, wannabe crazy (Oh yeah/Navy SEAL!)", singer: "others" },
        
        { time: 227.5, text: "Practically, I tactically destroy", singer: "others" },
        { time: 230.0, text: "Deploy more decoys than a presidential convoy (Oh yeah)", singer: "others" },
        { time: 232.5, text: "My whole envoy stay camouflaged out", singer: "others" },
        { time: 235.0, text: "And when I walk the street, I take the refugee route (Oh yeah)", singer: "others" },
        { time: 237.5, text: "This one go out to all my thugs in the borough", singer: "others" },
        { time: 240.0, text: "Soldiers stay thorough, like Kilamanjaro (Oh yeah)", singer: "others" },
        { time: 242.5, text: "Split it with an arrow, my girl platoon roll", singer: "others" },
        { time: 245.0, text: "Outta control, the female Mandingos (Oh yeah)", singer: "others" },
        { time: 247.5, text: "Free, I evolve from the egg of a seminarian", singer: "others" },
        { time: 250.0, text: "Don't go down, 'cause I'm a vegetarian (Oh yeah)", singer: "others" },
        { time: 252.5, text: "And when I bust, it ain't 'in God we trust'", singer: "others" },
        { time: 255.0, text: "And if you bring a gun, you better bring a black tusk (Oh yeah)", singer: "others" },
    // Outro
    { time: 257.5, text: "She looked into my eyes and said FBI", singer: "others" },
    { time: 260.0, text: "(Another one bites the dust) (Oh yeah)", singer: "freddie" },
    { time: 262.5, text: "She said she loved me, she was a spy who lied", singer: "others" },
    { time: 265.0, text: "(Another one bites the dust) Right", singer: "freddie" },
    { time: 267.5, text: "I could relate, could you relate?", singer: "others" },
    { time: 270.0, text: "(Another one bites the dust)", singer: "freddie" },
    { time: 272.5, text: "Jerry 'Wonda', The Product (Oh-oh) (Another one bites the dust)", singer: "others" },
    { time: 275.0, text: "Yo, Canibus, John Forté (Don't you know we coming for you?)", singer: "others" },
    { time: 277.5, text: "(Another one bites the dust) Yo, Dirty Cash, and baby Free", singer: "freddie" },
    { time: 280.0, text: "(Another one bites the dust)", singer: "others" },
    { time: 282.5, text: "(And another one gone) Wyclef Jean", singer: "freddie" },
    { time: 285.0, text: "(And another one gone) Freddie Mercury, ha-ha", singer: "freddie" },
    { time: 287.5, text: "(Another one bites the dust, yeah)", singer: "others" },
    { time: 290.0, text: "I'm out baby", singer: "others" },
    { time: 292.5, text: "Navy SEALs!", singer: "others" },
    { time: 295.0, text: "(Another one bites the dust)", singer: "freddie" },
    { time: 297.5, text: "(Another one bites the dust)", singer: "freddie" },
    { time: 300.0, text: "(Another one bites the dust)", singer: "freddie" },
];


let currentLyricIndex = 0;
const audio = document.getElementById("audio");
const freddieLyrics = document.getElementById("lyric-freddie");
const othersLyrics = document.getElementById("lyric-others");
let lyricsInterval; // Variable to store the interval


audio.addEventListener("play", () => {
    
    if (lyricsInterval) {
        clearInterval(lyricsInterval);
    }
    lyricsInterval = setInterval(displayLyrics, 100);
});


audio.addEventListener("ended", () => {
    clearInterval(lyricsInterval);
    currentLyricIndex = 0;
    freddieLyrics.textContent = "";
    othersLyrics.textContent = "";
});


function displayLyrics() {
    const currentTime = audio.currentTime;

    if (currentLyricIndex < lyrics.length && currentTime >= lyrics[currentLyricIndex].time) {
        if (lyrics[currentLyricIndex].singer === "freddie") {
            freddieLyrics.textContent = lyrics[currentLyricIndex].text;
            othersLyrics.textContent = ""; // Clear the other lyric field
        } else {
            othersLyrics.textContent = lyrics[currentLyricIndex].text;
            freddieLyrics.textContent = ""; // Clear Freddie's lyric field
        }
        currentLyricIndex++;
    }
}
